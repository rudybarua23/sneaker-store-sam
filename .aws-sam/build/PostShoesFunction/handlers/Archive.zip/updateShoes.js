exports.handler = async (event) => {
  let connection;

  try {
    console.log('Lambda function started for PUT shoe by ID.');

    const shoeId = event.pathParameters?.id;

    if (!shoeId) {
      console.error('Missing shoe ID in path parameters.');
      return { statusCode: 400, body: JSON.stringify({ message: 'Shoe ID is required.' }) };
    }

    if (!event.body) {
      console.error('Missing request body.');
      return { statusCode: 400, body: JSON.stringify({ message: 'Request body is required.' }) };
    }

    const { name, brand, price, size, in_stock } = JSON.parse(event.body);

    if (!name || !brand || price == null || size == null || in_stock == null) {
      console.error('Missing one or more required shoe fields.');
      return { statusCode: 400, body: JSON.stringify({ message: 'All shoe fields are required.' }) };
    }

    const response = await client.send(new GetSecretValueCommand({ SecretId: secret_name, VersionStage: "AWSCURRENT" }));
    const secret = JSON.parse(response.SecretString);

    connection = await mysql.createConnection({
      host: secret.host,
      user: secret.username,
      password: secret.password,
      database: secret.dbname,
    });

    const updateQuery = `
      UPDATE shoes 
      SET name = ?, brand = ?, price = ?, size = ?, in_stock = ? 
      WHERE id = ?
    `;
    const [result] = await connection.query(updateQuery, [name, brand, price, size, in_stock, shoeId]);

    if (result.affectedRows === 0) {
      console.warn(`Shoe with ID ${shoeId} not found for update.`);
      return { statusCode: 404, body: JSON.stringify({ message: 'Shoe not found.' }) };
    }

    return { statusCode: 200, body: JSON.stringify({ message: 'Shoe updated successfully.' }) };

  } catch (error) {
    console.error('Error updating shoe:', error);
    return { statusCode: 500, body: JSON.stringify({ message: 'Error updating shoe.', error: error.message }) };
  } finally {
    if (connection) {
      try {
        await connection.end();
        console.log('Database connection closed.');
      } catch (closeError) {
        console.error('Error closing the database connection:', closeError);
      }
    }
  }
};

