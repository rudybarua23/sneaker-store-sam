const mysql = require('mysql2/promise');
const { SecretsManagerClient, GetSecretValueCommand } = require('@aws-sdk/client-secrets-manager');

const secret_name = "admin_cred";
const client = new SecretsManagerClient({ region: "us-east-1" });

console.log('forcing cold start');

exports.handler = async (event) => {
  let connection;

  try {
    console.log('Lambda function started.');

    // Step 1: Retrieve DB credentials
    console.log('Retrieving database credentials from Secrets Manager...');
    const response = await client.send(
      new GetSecretValueCommand({
        SecretId: secret_name,
        VersionStage: "AWSCURRENT",
      })
    );
    console.log('Successfully retrieved secret from Secrets Manager.');

    const secret = JSON.parse(response.SecretString);
    console.log('Database host:', secret.host);
    console.log('Database user:', secret.username);

    // Step 2: Connect to the database
    console.log('Attempting to connect to the database...');
    connection = await mysql.createConnection({
      host: secret.host,
      user: secret.username,
      password: secret.password,
      database: secret.dbname,
      connectTimeout: 30000 // Increased timeout
    });
    console.log('Successfully connected to the database.');

    // Step 3: Bulletproof body parsing
    console.log('Parsing incoming sneaker data...');
    let requestBody;

    if (event.body) {
      if (typeof event.body === 'string') {
        requestBody = JSON.parse(event.body); // API Gateway request
      } else {
        requestBody = event.body; // Direct Lambda invocation with object body
      }
    } else {
      requestBody = event; // Fully direct object test (bypassing body)
    }

    const shoes = requestBody.shoes;

    console.log('Shoes data received:', JSON.stringify(shoes));

    if (!shoes || !Array.isArray(shoes) || shoes.length === 0) {
      console.error('Invalid or missing shoe data.');
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'Invalid or missing shoe data.' }),
      };
    }

    // Convert array of objects to array of arrays for SQL insertion
    const shoeValues = shoes.map(shoe => [
      shoe.name,
      shoe.brand,
      shoe.price,
      shoe.size,
      shoe.in_stock
    ]);

    // Step 4: Batched insert
    const batchSize = 10;
    let totalInserted = 0;

    for (let i = 0; i < shoeValues.length; i += batchSize) {
      const batch = shoeValues.slice(i, i + batchSize);
      console.log(`Inserting batch: ${JSON.stringify(batch)}`);
      const insertQuery = 'INSERT INTO shoes (name, brand, price, size, in_stock) VALUES ?';
      const [result] = await connection.query(insertQuery, [batch]);
      console.log(`Inserted batch of ${result.affectedRows} shoes.`);
      totalInserted += result.affectedRows;
    }

    return {
      statusCode: 200,
      body: JSON.stringify({ message: `Shoes seeded successfully! Inserted ${totalInserted} shoes.` }),
    };
  } catch (error) {
    console.error('Error occurred:', error);
    console.error('Error stack trace:', error.stack);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Seeding failed.', error: error.message }),
    };
  } finally {
    if (connection) {
      try {
        console.log('Closing database connection...');
        await connection.end();
        console.log('Database connection closed.');
      } catch (closeError) {
        console.error('Error closing the database connection:', closeError);
      }
    }
  }
};
