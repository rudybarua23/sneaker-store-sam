exports.handler = async (event) => {
  let connection;

  try {
    console.log('Lambda function started for DELETE shoe by ID.');

    const shoeId = event.pathParameters?.id;

    if (!shoeId) {
      console.error('Missing shoe ID in path parameters.');
      return { statusCode: 400, body: JSON.stringify({ message: 'Shoe ID is required.' }) };
    }

    const response = await client.send(new GetSecretValueCommand({ SecretId: secret_name, VersionStage: "AWSCURRENT" }));
    const secret = JSON.parse(response.SecretString);

    connection = await mysql.createConnection({
      host: secret.host,
      user: secret.username,
      password: secret.password,
      database: secret.dbname,
    });

    const [result] = await connection.query('DELETE FROM shoes WHERE id = ?', [shoeId]);

    if (result.affectedRows === 0) {
      console.warn(`Shoe with ID ${shoeId} not found for deletion.`);
      return { statusCode: 404, body: JSON.stringify({ message: 'Shoe not found.' }) };
    }

    return { statusCode: 200, body: JSON.stringify({ message: 'Shoe deleted successfully.' }) };

  } catch (error) {
    console.error('Error deleting shoe:', error);
    return { statusCode: 500, body: JSON.stringify({ message: 'Error deleting shoe.', error: error.message }) };
  } finally {
    if (connection) {
      try {
        await connection.end();
        console.log('Database connection closed.');
      } catch (closeError) {
        console.error('Error closing the database connection:', closeError);
      }
    }
  }
};
