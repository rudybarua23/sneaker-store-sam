const mysql = require('mysql2/promise');
const { SecretsManagerClient, GetSecretValueCommand } = require('@aws-sdk/client-secrets-manager');

const secret_name = "admin_cred";
const client = new SecretsManagerClient({ region: "us-east-1" });

exports.handler = async (event) => {
  let connection;

  try {
    console.log('Lambda function started for GET all shoes.');

    const response = await client.send(new GetSecretValueCommand({ SecretId: secret_name, VersionStage: "AWSCURRENT" }));
    const secret = JSON.parse(response.SecretString);

    connection = await mysql.createConnection({
      host: secret.host,
      user: secret.username,
      password: secret.password,
      database: secret.dbname,
    });

    const queryParams = event.queryStringParameters;
    let query = 'SELECT * FROM shoes';
    let values = [];

    if (queryParams && queryParams.brand) {
      query += ' WHERE brand = ?';
      values.push(queryParams.brand);
    }

    const [rows] = await connection.query(query, values);

    return {
      statusCode: 200,
      body: JSON.stringify(rows),
    };

  } catch (error) {
    console.error('Error fetching shoes:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Error fetching shoes.', error: error.message }),
    };
  } finally {
    if (connection) {
      try {
        await connection.end();
        console.log('Database connection closed.');
      } catch (closeError) {
        console.error('Error closing the database connection:', closeError);
      }
    }
  }
};
