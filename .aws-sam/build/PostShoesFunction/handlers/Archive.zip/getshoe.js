exports.handler = async (event) => {
  let connection;

  try {
    console.log('Lambda function started for GET shoe by ID.');

    const shoeId = event.pathParameters?.id;

    if (!shoeId) {
      console.error('Missing shoe ID in path parameters.');
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'Shoe ID is required.' }),
      };
    }

    const response = await client.send(new GetSecretValueCommand({ SecretId: secret_name, VersionStage: "AWSCURRENT" }));
    const secret = JSON.parse(response.SecretString);

    connection = await mysql.createConnection({
      host: secret.host,
      user: secret.username,
      password: secret.password,
      database: secret.dbname,
    });

    const [rows] = await connection.query('SELECT * FROM shoes WHERE id = ?', [shoeId]);

    if (rows.length === 0) {
      console.warn(`Shoe with ID ${shoeId} not found.`);
      return { statusCode: 404, body: JSON.stringify({ message: 'Shoe not found.' }) };
    }

    return {
      statusCode: 200,
      body: JSON.stringify(rows[0]),
    };

  } catch (error) {
    console.error('Error fetching shoe by ID:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Error fetching shoe.', error: error.message }),
    };
  } finally {
    if (connection) {
      try {
        await connection.end();
        console.log('Database connection closed.');
      } catch (closeError) {
        console.error('Error closing the database connection:', closeError);
      }
    }
  }
};
